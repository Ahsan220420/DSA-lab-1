#include <iostream>
#include "Queue.h"
using namespace std;

int main() {
    int cap;
    cout << "Enter capacity: ";
    cin >> cap;

    Queue q(cap);

    int choice, id;

    do {
        cout << "\n1 Add Ticket\n2 Resolve Ticket\n3 Next Ticket\n4 Display\n0 Exit\n";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter 4-digit ticket ID: ";
            cin >> id;
            if (id >= 1000 && id <= 9999)
                q.enqueue(id);
            else
                cout << "Invalid ID\n";
            break;

        case 2:
            cout << "Resolved: " << q.dequeue() << endl;
            break;

        case 3:
            cout << "Next: " << q.front() << endl;
            break;

        case 4:
            q.display();
            break;
        }
    } while (choice != 0);

    return 0;
}