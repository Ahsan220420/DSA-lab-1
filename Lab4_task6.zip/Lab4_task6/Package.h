#ifndef PACKAGE_H
#define PACKAGE_H

#include <string>
using namespace std;

struct Package {
    int id;
    string address;
    int startTime;
    int endTime;
};

#endif