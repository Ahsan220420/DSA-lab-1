#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
#include "Package.h"
using namespace std;

class Queue {
private:
    Package* arr;
    int frontIndex;
    int rearIndex;
    int size;
    int capacity;

public:
    Queue(int cap) {
        capacity = cap;
        arr = new Package[capacity];
        frontIndex = 0;
        rearIndex = -1;
        size = 0;
    }

    void enqueue(Package p) {
        if (size == capacity) {
            cout << "Queue full\n";
            return;
        }
        rearIndex = (rearIndex + 1) % capacity;
        arr[rearIndex] = p;
        size++;
    }

    void dequeue() {
        if (isEmpty()) {
            cout << "Queue empty\n";
            return;
        }
        frontIndex = (frontIndex + 1) % capacity;
        size--;
    }

    Package front() {
        return arr[frontIndex];
    }

    bool isEmpty() {
        return size == 0;
    }

    void display() {
        if (isEmpty()) {
            cout << "No packages\n";
            return;
        }
        int i = frontIndex;
        for (int c = 0; c < size; c++) {
            cout << "ID:" << arr[i].id << " ";
            cout << "Addr:" << arr[i].address << " ";
            cout << "Time:" << arr[i].startTime << "-" << arr[i].endTime << endl;
            i = (i + 1) % capacity;
        }
    }

    bool timeToDeliver(int currentTime) {
        while (!isEmpty()) {
            Package p = front();
            if (currentTime >= p.startTime && currentTime <= p.endTime) {
                cout << "Delivering Package ID: " << p.id << endl;
                dequeue();
                return true;
            } else {
                cout << "Expired Package ID: " << p.id << endl;
                dequeue();
            }
        }
        cout << "No package available\n";
        return false;
    }

    ~Queue() {
        delete[] arr;
    }
};

#endif