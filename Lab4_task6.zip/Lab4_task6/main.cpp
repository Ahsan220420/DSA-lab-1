#include <iostream>
#include "Queue.h"
using namespace std;

int main() {
    int cap;
    cout << "Enter capacity: ";
    cin >> cap;

    Queue q(cap);

    int choice;

    do {
        cout << "\n1 Add Package\n2 Deliver\n3 Front\n4 Display\n0 Exit\n";
        cin >> choice;

        if (choice == 1) {
            Package p;
            cout << "Enter ID: ";
            cin >> p.id;
            cout << "Enter address: ";
            cin >> p.address;
            cout << "Start time: ";
            cin >> p.startTime;
            cout << "End time: ";
            cin >> p.endTime;
            q.enqueue(p);
        }

        else if (choice == 2) {
            int currentTime;
            cout << "Enter current time: ";
            cin >> currentTime;
            q.timeToDeliver(currentTime);
        }

        else if (choice == 3) {
            if (!q.isEmpty()) {
                Package p = q.front();
                cout << "ID:" << p.id << " Addr:" << p.address << " Time:" << p.startTime << "-" << p.endTime << endl;
            }
        }

        else if (choice == 4) {
            q.display();
        }

    } while (choice != 0);

    return 0;
}