#include <iostream>
#include "Queue.h"
using namespace std;

int main() {
    int cap;
    cout << "Enter capacity: ";
    cin >> cap;

    Queue q(cap);

    int choice;
    string name;

    do {
        cout << "\n1 Add Document\n2 Print Document\n3 Front Document\n4 Display\n0 Exit\n";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter document name: ";
            cin >> name;
            q.enqueue(name);
            break;

        case 2:
            cout << "Printed: " << q.dequeue() << endl;
            break;

        case 3:
            cout << "Front: " << q.front() << endl;
            break;

        case 4:
            q.display();
            break;
        }
    } while (choice != 0);

    return 0;
}