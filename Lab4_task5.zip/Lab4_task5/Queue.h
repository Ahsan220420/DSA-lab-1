#ifndef QUEUE_H
#define QUEUE_H

#include <iostream>
#include <string>
using namespace std;

class Queue {
private:
    string* arr;
    int frontIndex;
    int rearIndex;
    int size;
    int capacity;

public:
    Queue(int cap) {
        capacity = cap;
        arr = new string[capacity];
        frontIndex = 0;
        rearIndex = -1;
        size = 0;
    }

    void enqueue(string document_name) {
        if (size == capacity) {
            cout << "Queue full\n";
            return;
        }
        rearIndex = (rearIndex + 1) % capacity;
        arr[rearIndex] = document_name;
        size++;
    }

    string dequeue() {
        if (isEmpty()) {
            cout << "Queue empty\n";
            return "";
        }
        string val = arr[frontIndex];
        frontIndex = (frontIndex + 1) % capacity;
        size--;
        return val;
    }

    string front() {
        if (isEmpty()) {
            cout << "Queue empty\n";
            return "";
        }
        return arr[frontIndex];
    }

    bool isEmpty() {
        return size == 0;
    }

    void display() {
        if (isEmpty()) {
            cout << "No documents\n";
            return;
        }
        int i = frontIndex;
        for (int c = 0; c < size; c++) {
            cout << arr[i] << " ";
            i = (i + 1) % capacity;
        }
        cout << endl;
    }

    ~Queue() {
        delete[] arr;
    }
};

#endif