#ifndef QUEUEUSINGSTACK_H
#define QUEUEUSINGSTACK_H

#include <iostream>
#include <stack>
using namespace std;

class QueueUsingStack {
private:
    stack<int> s1, s2;

    void transfer() {
        if (s2.empty()) {
            while (!s1.empty()) {
                s2.push(s1.top());
                s1.pop();
            }
        }
    }

public:
    void enqueue(int x) {
        s1.push(x);
    }

    int dequeue() {
        transfer();
        if (s2.empty()) {
            cout << "Queue empty\n";
            return -1;
        }
        int val = s2.top();
        s2.pop();
        return val;
    }

    int front() {
        transfer();
        if (s2.empty()) {
            cout << "Queue empty\n";
            return -1;
        }
        return s2.top();
    }

    void display() {
        stack<int> temp1 = s1;
        stack<int> temp2 = s2;
        stack<int> result;

        while (!temp2.empty()) {
            result.push(temp2.top());
            temp2.pop();
        }

        while (!temp1.empty()) {
            result.push(temp1.top());
            temp1.pop();
        }

        while (!result.empty()) {
            cout << result.top() << " ";
            result.pop();
        }
        cout << endl;
    }
};

#endif