#include <iostream>
#include "QueueUsingStack.h"
using namespace std;

int main() {
    QueueUsingStack q;
    int choice, value;

    do {
        cout << "\n1 Enqueue\n2 Dequeue\n3 Front\n4 Display\n0 Exit\n";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value: ";
            cin >> value;
            q.enqueue(value);
            break;
        case 2:
            cout << "Removed: " << q.dequeue() << endl;
            break;
        case 3:
            cout << "Front: " << q.front() << endl;
            break;
        case 4:
            q.display();
            break;
        }
    } while (choice != 0);

    return 0;
}