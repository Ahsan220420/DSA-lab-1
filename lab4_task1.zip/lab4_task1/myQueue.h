#ifndef MYQUEUE_H
#define MYQUEUE_H

#include <iostream>
#include "AbstractQueue.h"
using namespace std;

template <typename T>
class myQueue : public AbstractQueue<T> {
private:
    T* arr;
    int frontIndex;
    int rearIndex;
    int capacity;
    int count;

public:
    myQueue(int size) {
        capacity = size;
        arr = new T[capacity];
        frontIndex = 0;
        rearIndex = -1;
        count = 0;
    }

    void enQueue(T value) {
        if (isFull()) {
            cout << "Queue is full\n";
            return;
        }
        rearIndex = (rearIndex + 1) % capacity;
        arr[rearIndex] = value;
        count++;
    }

    T deQueue() {
        if (isEmpty()) {
            cout << "Queue is empty\n";
            return T();
        }
        T value = arr[frontIndex];
        frontIndex = (frontIndex + 1) % capacity;
        count--;
        return value;
    }

    T front() const {
        if (isEmpty()) {
            cout << "Queue is empty\n";
            return T();
        }
        return arr[frontIndex];
    }

    bool isEmpty() const {
        return count == 0;
    }

    bool isFull() const {
        return count == capacity;
    }

    void display() const {
        if (isEmpty()) {
            cout << "Queue is empty\n";
            return;
        }
        int i = frontIndex;
        for (int c = 0; c < count; c++) {
            cout << arr[i] << " ";
            i = (i + 1) % capacity;
        }
        cout << endl;
    }

    ~myQueue() {
        delete[] arr;
    }
};

#endif