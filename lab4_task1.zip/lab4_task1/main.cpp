#include <iostream>
#include "myQueue.h"
using namespace std;

int main() {
    int size;
    cout << "Enter queue size: ";
    cin >> size;

    myQueue<int> q(size);

    int choice, value;

    do {
        cout << "\n1. Enqueue\n2. Dequeue\n3. Front\n4. Is Empty\n5. Is Full\n6. Display\n0. Exit\n";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value: ";
            cin >> value;
            q.enQueue(value);
            break;
        case 2:
            cout << "Dequeued: " << q.deQueue() << endl;
            break;
        case 3:
            cout << "Front: " << q.front() << endl;
            break;
        case 4:
            cout << (q.isEmpty() ? "Queue is empty\n" : "Queue is not empty\n");
            break;
        case 5:
            cout << (q.isFull() ? "Queue is full\n" : "Queue is not full\n");
            break;
        case 6:
            q.display();
            break;
        }
    } while (choice != 0);

    return 0;
}