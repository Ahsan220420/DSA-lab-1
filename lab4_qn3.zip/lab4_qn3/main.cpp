#include <iostream>
#include <stack>
#include "Queue.h"
using namespace std;

int main() {
    int n;
    cout << "Enter size: ";
    cin >> n;

    Queue q(n);

    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        int x;
        cin >> x;
        q.enqueue(x);
    }

    int k;
    cout << "Enter K: ";
    cin >> k;

    if (k > q.getSize()) k = q.getSize();

    if (k > 1) {
        stack<int> s;

        for (int i = 0; i < k; i++) {
            s.push(q.dequeue());
        }

        while (!s.empty()) {
            q.enqueue(s.top());
            s.pop();
        }

        int rem = q.getSize() - k;
        for (int i = 0; i < rem; i++) {
            q.enqueue(q.dequeue());
        }
    }

    cout << "Output: ";
    q.display();

    return 0;
}